﻿using UnityEngine;

namespace Project.Оld.Common.Entities
{
    public abstract class Entity<T> : MonoBehaviour where T : EntityData
    {
        [Header("Entity Data")]
        [SerializeField]
        protected T _data;

        public T Data => _data;
        public int Id => _data?.Id ?? -1;

        public virtual void Init(T data)
        {
            _data = data;
        }
        
        public bool CanMatchWithData(Entity<T> other)
        {
            return other && _data == other._data;
        }

        public bool CanMatchWith(T data)
        {
            return _data == data;
        }
        
        public bool CanMatchById(int id)
        {
            return Id == id;
        }

        public bool CanMatchById(Entity<T> other)
        {
            return other && Id == other.Id;
        }
        
        public static implicit operator T(Entity<T> entity)
        {
            return entity?._data;
        }

        public static implicit operator int(Entity<T> entity)
        {
            return entity?.Id ?? -1;
        }
    }
}