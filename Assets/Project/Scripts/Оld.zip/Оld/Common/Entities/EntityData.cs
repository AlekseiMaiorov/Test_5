﻿using UnityEngine;

namespace Project.Оld.Common.Entities
{
    public abstract class EntityData : ScriptableObject
    {
        [Header("Entity Info")]
        [SerializeField]
        private int _id;

        public int Id => _id;
    }
}