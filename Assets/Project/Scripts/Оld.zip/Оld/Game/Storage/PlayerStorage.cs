﻿using Project.Оld.Game.Settings;
using UnityEngine;
using Zenject;

namespace Project.Оld.Game.Storage
{
    public interface IPlayerStorage
    {
        int CurrentScore { get; }
        int CurrentHealth { get; }
        int MaxHealth { get; }
        void AddScore(int points);
        void TakeDamage(int damage);
        void ResetStats();
    }

    public sealed class PlayerStorage : IPlayerStorage, IInitializable
    {
        private readonly SignalBus _signalBus;
        private readonly GameSettings _gameSettings;

        private int _currentScore = 0;
        private int _currentHealth;

        public int CurrentScore => _currentScore;
        public int CurrentHealth => _currentHealth;
        public int MaxHealth => _gameSettings.PlayerHealth;

        public PlayerStorage(SignalBus signalBus, GameSettings gameSettings)
        {
            _signalBus = signalBus;
            _gameSettings = gameSettings;
        }

        public void Initialize()
        {
            ResetStats();
        }

        public void AddScore(int points)
        {
            _currentScore += points;
            
            var scoreSignal = new ScoreChangedSignal
            {
                CurrentScore = _currentScore,
                ScoreChange = points
            };
            
            _signalBus.Fire(scoreSignal);
        }

        public void TakeDamage(int damage)
        {
            int previousHealth = _currentHealth;
            _currentHealth = Mathf.Max(0, _currentHealth - damage);
            
            var healthSignal = new PlayerHealthChangedSignal
            {
                CurrentHealth = _currentHealth,
                MaxHealth = MaxHealth,
                HealthChange = _currentHealth - previousHealth
            };
            
            _signalBus.Fire(healthSignal);
        }

        public void ResetStats()
        {
            _currentScore = 0;
            _currentHealth = _gameSettings.PlayerHealth;
            
            var scoreSignal = new ScoreChangedSignal
            {
                CurrentScore = _currentScore,
                ScoreChange = 0
            };
            
            var healthSignal = new PlayerHealthChangedSignal
            {
                CurrentHealth = _currentHealth,
                MaxHealth = MaxHealth,
                HealthChange = 0
            };
            
            _signalBus.Fire(scoreSignal);
            _signalBus.Fire(healthSignal);
        }
    }
}