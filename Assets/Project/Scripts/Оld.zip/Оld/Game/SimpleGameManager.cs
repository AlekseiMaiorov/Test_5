﻿namespace Project.Оld.Game
{
    public class SimpleGameManager
    {
        
    }
}