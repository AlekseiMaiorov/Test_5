﻿using Project.Оld.Game.Handlers;
using Project.Оld.Game.Pools;
using Project.Оld.Game.Servicies;
using UnityEngine;
using Zenject;

namespace Project.Оld.Game.Installers
{
    public class ParticleInstaller : MonoInstaller
    {
        [Header("Pool Settings")]
        [SerializeField]
        private GameObject _particlePoolPrefab;
        
        [SerializeField]
        private int _initialPoolSize = 5;

        public override void InstallBindings()
        {
            Container.BindMemoryPool<ParticlePool, ParticlePool.Pool>()
                     .WithInitialSize(_initialPoolSize)
                     .FromComponentInNewPrefab(_particlePoolPrefab)
                     .UnderTransformGroup("ParticlePool");

            Container.Bind<IParticleService>()
                     .To<ParticleService>()
                     .FromComponentInHierarchy()
                     .AsSingle();

            Container.Bind<ParticleHandler>()
                     .FromComponentInHierarchy()
                     .AsSingle();
        }
    }
}