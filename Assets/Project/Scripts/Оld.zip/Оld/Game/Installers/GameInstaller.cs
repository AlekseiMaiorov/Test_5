﻿using Zenject;

namespace Project.Оld.Game.Installers
{
    public class GameInstaller : MonoInstaller
    {
        public override void InstallBindings()
        {
            
        }
    }
}