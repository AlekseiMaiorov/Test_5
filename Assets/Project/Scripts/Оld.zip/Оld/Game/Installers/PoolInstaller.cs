﻿using Project.Оld.Game.Pools;
using Zenject;

namespace Project.Оld.Game.Installers
{
    public class ShapePoolInstaller : MonoInstaller
    {
        public override void InstallBindings()
        {
            Container.Bind<IShapePool>()
                     .To<ShapePool>()
                     .AsSingle();
        }
    }
}