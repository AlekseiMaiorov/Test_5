﻿using Project.Оld.Game.Factories;
using Project.Оld.Game.Shape;
using UnityEngine;
using Zenject;

namespace Project.Оld.Game.Installers
{
    public class ShapeFactoryInstaller : MonoInstaller
    {
        [Header("Shape Settings")]
        [SerializeField]
        private ShapePrefabLibrary _shapePrefabLibrary;

        public override void InstallBindings()
        {
            Container.Bind<ShapePrefabLibrary>()
                     .FromInstance(_shapePrefabLibrary)
                     .AsSingle();

            Container.Bind<IShapeFactory>()
                     .To<ShapeFactory>()
                     .AsSingle();
        }
    }
}