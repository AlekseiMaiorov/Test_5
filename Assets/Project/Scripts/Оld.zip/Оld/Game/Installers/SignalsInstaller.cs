﻿using Zenject;

namespace Project.Оld.Game.Installers
{
    public class SignalsInstaller : MonoInstaller
    {
        public override void InstallBindings()
        {
            
        }
    }
}