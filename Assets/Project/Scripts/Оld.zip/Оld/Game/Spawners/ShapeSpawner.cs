﻿using System;
using System.Collections.Generic;
using System.Threading;
using Cysharp.Threading.Tasks;
using Project.Оld.Game.Pools;
using Project.Оld.Game.Settings;
using Project.Оld.Game.Shape;
using Project.Оld.Game.Slots;
using UnityEngine;
using Zenject;
using Random = UnityEngine.Random;

namespace Project.Оld.Game.Spawners
{
    public sealed class ShapeSpawner : MonoBehaviour, IInitializable
    {
        private SignalBus _signalBus;
        private IShapePool _shapePool;
        private ISortingSlotsProvider _slotsProvider;
        private GameSettings _gameSettings;
        
        [SerializeField]
        private Transform[] _spawnPoints = new Transform[3];

        private bool _isSpawning = false;
        private int _totalShapesToSpawn;
        private int _shapesSpawned = 0;
        private CancellationTokenSource _cancellationTokenSource;
        private List<ShapeData> _availableShapeData = new List<ShapeData>();

        [Inject]
        private void Init(SignalBus signalBus, IShapePool shapePool, ISortingSlotsProvider slotsProvider, GameSettings gameSettings)
        {
            _signalBus = signalBus;
            _shapePool = shapePool;
            _slotsProvider = slotsProvider;
            _gameSettings = gameSettings;
        }

        public void Initialize()
        {
            SubscribeToSignals();
            InitializeShapeData();
            InitializeSpawnCount();
            _cancellationTokenSource = new CancellationTokenSource();
        }

        private void OnDestroy()
        {
            UnsubscribeFromSignals();
            _cancellationTokenSource?.Cancel();
            _cancellationTokenSource?.Dispose();
        }

        private void SubscribeToSignals()
        {
            _signalBus.Subscribe<StartSpawnShapesSignal>(OnStartSpawnShapes);
            _signalBus.Subscribe<StopSpawnShapesSignal>(OnStopSpawnShapes);
        }

        private void UnsubscribeFromSignals()
        {
            _signalBus.TryUnsubscribe<StartSpawnShapesSignal>(OnStartSpawnShapes);
            _signalBus.TryUnsubscribe<StopSpawnShapesSignal>(OnStopSpawnShapes);
        }

        private void InitializeShapeData()
        {
            _availableShapeData = _slotsProvider.GetAvailableShapeData();
        }

        private void InitializeSpawnCount()
        {
            _totalShapesToSpawn = Mathf.RoundToInt(Random.Range(_gameSettings.ShapesToSpawnRange.x, _gameSettings.ShapesToSpawnRange.y));
            _shapesSpawned = 0;
        }

        private void OnStartSpawnShapes()
        {
            StartSpawningAsync(_cancellationTokenSource.Token).Forget();
        }

        private void OnStopSpawnShapes()
        {
            StopSpawning();
        }

        private async UniTaskVoid StartSpawningAsync(CancellationToken cancellationToken)
        {
            if (_isSpawning || _availableShapeData.Count == 0)
            {
                return;
            }

            _isSpawning = true;

            while (_isSpawning && _shapesSpawned < _totalShapesToSpawn && !cancellationToken.IsCancellationRequested)
            {
                SpawnRandomShape();
                
                float delay = Random.Range(_gameSettings.SpawnTimeoutRange.x, _gameSettings.SpawnTimeoutRange.y);
                await UniTask.Delay(TimeSpan.FromSeconds(delay), cancellationToken: cancellationToken);
            }

            _isSpawning = false;
            
            if (_shapesSpawned >= _totalShapesToSpawn)
            {
                _signalBus.Fire<StopSpawnShapesSignal>();
            }
        }

        private void StopSpawning()
        {
            _isSpawning = false;
        }

        private void SpawnRandomShape()
        {
            if (_spawnPoints.Length == 0 || _availableShapeData.Count == 0)
            {
                return;
            }

            int laneIndex = Random.Range(0, _spawnPoints.Length);
            Transform spawnPoint = _spawnPoints[laneIndex];
            
            if (!spawnPoint)
            {
                return;
            }

            ShapeData randomShapeData = GetRandomShapeData();
            DefaultShape spawnedShape = _shapePool.GetShape(randomShapeData, spawnPoint.position);
            
            if (spawnedShape)
            {
                _shapesSpawned++;
                
                var signal = new ShapeSpawnedSignal
                {
                    Shape = spawnedShape,
                    SpawnPosition = spawnPoint.position,
                    SpawnLane = laneIndex
                };
                
                _signalBus.Fire(signal);
            }
        }

        private ShapeData GetRandomShapeData()
        {
            int randomIndex = Random.Range(0, _availableShapeData.Count);
            return _availableShapeData[randomIndex];
        }
    }
}