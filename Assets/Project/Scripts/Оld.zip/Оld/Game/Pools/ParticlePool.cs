﻿using UnityEngine;
using Zenject;

namespace Project.Оld.Game.Pools
{
    public sealed class ParticlePool : MonoBehaviour, IPoolable<ParticleSystem, Vector3, IMemoryPool>,
        System.IDisposable
    {
        private ParticleSystem _prefab;
        private ParticleSystem _particleSystem;
        private IMemoryPool _pool;

        public void OnDespawned()
        {
            _pool = null;
            _prefab = null;

            if (_particleSystem)
            {
                _particleSystem.Stop();
                _particleSystem.Clear();
            }

            gameObject.SetActive(false);
        }

        public void OnSpawned(ParticleSystem prefab, Vector3 position, IMemoryPool pool)
        {
            _prefab = prefab;
            _pool = pool;

            transform.position = position;
            gameObject.SetActive(true);

            SetupParticleSystem();
        }

        public void PlayEffect()
        {
            if (_particleSystem)
            {
                _particleSystem.Play();

                float duration = GetEffectDuration();
                Invoke(nameof(ReturnToPool), duration);
            }
        }

        public void Dispose()
        {
            ReturnToPool();
        }

        private void SetupParticleSystem()
        {
            if (!_particleSystem)
            {
                _particleSystem = GetComponent<ParticleSystem>();
            }

            if (_particleSystem && _prefab)
            {
                var main = _particleSystem.main;
                var prefabMain = _prefab.main;

                main.startLifetime = prefabMain.startLifetime;
                main.startSpeed = prefabMain.startSpeed;
                main.startColor = prefabMain.startColor;
                main.startSize = prefabMain.startSize;
                main.maxParticles = prefabMain.maxParticles;
            }
        }

        private float GetEffectDuration()
        {
            if (!_particleSystem)
            {
                return 1f;
            }

            var main = _particleSystem.main;
            return main.startLifetime.constantMax + main.duration;
        }

        private void ReturnToPool()
        {
            CancelInvoke();
            _pool?.Despawn(this);
        }

        public class Pool : MemoryPool<ParticleSystem, Vector3, ParticlePool>
        {
        }
    }
}