﻿using System.Collections.Generic;
using Project.Оld.Game.Factories;
using Project.Оld.Game.Shape;
using UnityEngine;

namespace Project.Оld.Game.Pools
{
    public interface IShapePool
    {
        DefaultShape GetShape(ShapeData shapeData, Vector3 position);
        void ReturnShape(DefaultShape shape);
        void PrewarmPool(ShapeData shapeData, int count);
        void ClearPool();
    }

    public sealed class ShapePool : IShapePool
    {
        private const string SHAPE_POOL = "ShapePool";
        private readonly IShapeFactory _shapeFactory;
        private readonly Dictionary<ShapeType, Queue<DefaultShape>> _poolsByType = new Dictionary<ShapeType, Queue<DefaultShape>>();
        private readonly HashSet<DefaultShape> _activeShapes = new HashSet<DefaultShape>();
        private readonly Transform _poolParent;

        public ShapePool(IShapeFactory shapeFactory)
        {
            _shapeFactory = shapeFactory;
            
            GameObject poolContainer = new GameObject(SHAPE_POOL);
            _poolParent = poolContainer.transform;
            Object.DontDestroyOnLoad(poolContainer);
        }

        public DefaultShape GetShape(ShapeData shapeData, Vector3 position)
        {
            DefaultShape shape = GetFromPoolOrCreate(shapeData);

            if (!shape)
            {
                return shape;
            }

            shape.transform.position = position;
            shape.gameObject.SetActive(true);
            shape.Init(shapeData);
            _activeShapes.Add(shape);

            return shape;
        }

        public void ReturnShape(DefaultShape shape)
        {
            if (!shape || !_activeShapes.Contains(shape))
            {
                return;
            }

            _activeShapes.Remove(shape);
            shape.gameObject.SetActive(false);
            shape.transform.SetParent(_poolParent);

            ShapeType shapeType = shape.Data.ShapeType;
            GetPoolForType(shapeType).Enqueue(shape);
        }

        public void PrewarmPool(ShapeData shapeData, int count)
        {
            ShapeType shapeType = shapeData.ShapeType;
            Queue<DefaultShape> pool = GetPoolForType(shapeType);

            for (int i = 0; i < count; i++)
            {
                DefaultShape shape = _shapeFactory.CreateShape(shapeData, Vector3.zero);
                if (shape)
                {
                    shape.gameObject.SetActive(false);
                    shape.transform.SetParent(_poolParent);
                    pool.Enqueue(shape);
                }
            }

            Debug.Log($"Pool prewarmed for {shapeType}: {count} objects");
        }

        public void ClearPool()
        {
            foreach (var pool in _poolsByType.Values)
            {
                while (pool.Count > 0)
                {
                    DefaultShape shape = pool.Dequeue();
                    if (shape)
                    {
                        Object.Destroy(shape.gameObject);
                    }
                }
            }

            foreach (DefaultShape activeShape in _activeShapes)
            {
                if (activeShape)
                {
                    Object.Destroy(activeShape.gameObject);
                }
            }

            _poolsByType.Clear();
            _activeShapes.Clear();
        }

        private DefaultShape GetFromPoolOrCreate(ShapeData shapeData)
        {
            ShapeType shapeType = shapeData.ShapeType;
            Queue<DefaultShape> pool = GetPoolForType(shapeType);

            if (pool.Count > 0)
            {
                return pool.Dequeue();
            }
            
            DefaultShape newShape = _shapeFactory.CreateShape(shapeData, Vector3.zero);
            if (newShape)
            {
                newShape.transform.SetParent(_poolParent);
            }

            return newShape;
        }

        private Queue<DefaultShape> GetPoolForType(ShapeType shapeType)
        {
            if (!_poolsByType.ContainsKey(shapeType))
            {
                _poolsByType[shapeType] = new Queue<DefaultShape>();
            }

            return _poolsByType[shapeType];
        }
    }
}