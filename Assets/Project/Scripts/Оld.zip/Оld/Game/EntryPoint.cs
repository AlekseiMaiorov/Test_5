﻿using UnityEngine;
using Zenject;

namespace Project.Оld.Game
{
    public class EntryPoint: MonoBehaviour , IInitializable
    {
        private GameStateMachine _gameStateMachine;

        [Inject]
        private void Init(GameStateMachine gameStateMachine)
        {
            _gameStateMachine = gameStateMachine;
        }
        
        public void Initialize()
        {
            _gameStateMachine.ChangeState<LoadGameState>();
        }
    }
}