﻿using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Zenject;

namespace Project.Оld.Game.Behaviours
{
    public sealed class SlotDetector : MonoBehaviour
    {
        [Header("Detection Settings")]
        [SerializeField]
        private float _detectionRadius = 1f;

        private IReadOnlyList<SortingSlot> _availableSlots;

        [Inject]
        public void Init(IReadOnlyList<SortingSlot> slots)
        {
            _availableSlots = slots;
        }

        public SortingSlot GetSlotAtPosition(Vector3 position)
        {
            if (_availableSlots == null || _availableSlots.Count == 0)
            {
                return null;
            }

            return _availableSlots.FirstOrDefault(slot => IsPositionInSlot(position, slot));
        }

        private bool IsPositionInSlot(Vector3 position, SortingSlot slot)
        {
            if (!slot)
            {
                return false;
            }

            Collider2D slotCollider = slot.GetComponent<Collider2D>();
            if (slotCollider)
            {
                return slotCollider.bounds.Contains(position);
            }
            
            float distance = Vector3.Distance(position, slot.transform.position);
            return distance <= _detectionRadius;
        }

        public void SetDetectionRadius(float radius)
        {
            _detectionRadius = radius;
        }
    }
}