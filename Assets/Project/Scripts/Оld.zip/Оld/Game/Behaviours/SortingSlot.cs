﻿using Project.Оld.Common.Entities;
using UnityEngine;
using UnityEngine.Serialization;

namespace Project.Оld.Game.Behaviours
{
    public class SortingSlot : MonoBehaviour
    {
        [FormerlySerializedAs("_acceptedData")]
        [Header("Slot Settings")]
        [SerializeField]
        private EntityData _data;

        public EntityData Data=> _data;

        public void SetAcceptedShapeData(EntityData shapeData)
        {
            _data = shapeData;
        }
    }
}