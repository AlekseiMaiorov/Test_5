﻿using DG.Tweening;
using Project.Оld.Game.Behaviours.Handlers;
using Project.Оld.Game.Shape;
using Project.Оld.Inputs.Components;
using UnityEngine;
using Zenject;

namespace Project.Оld.Game.Behaviours.Shapes
{
    public sealed class DefaultShapeBehaviour : MonoBehaviour
    {
        private SignalBus _signalBus;
        
        [Header("Components")]
        [SerializeField]
        private DefaultShape _shape;

        [SerializeField]
        private Draggable _draggable;

        [SerializeField]
        private PositionSaver _positionSaver;

        [SerializeField]
        private LinearMover _linearMover;

        [Header("Handlers")]
        [SerializeField]
        private ShapeMatchHandler _matchHandler;
        

        [Header("Settings")]
        [SerializeField]
        private float _returnAnimationDuration = 0.5f;
        private SlotDetector _slotDetector;

        [Inject]
        private void Init(SignalBus signalBus, SlotDetector slotDetector)
        {
            _slotDetector = slotDetector;
            _signalBus = signalBus;
        }

        private void Start()
        {
            SetupComponents();
            SubscribeToEvents();
        }

        private void OnDestroy()
        {
            UnsubscribeFromEvents();
        }

        private void SetupComponents()
        {
            if (!_shape)
            {
                _shape = GetComponent<DefaultShape>();
            }

            if (!_draggable)
            {
                _draggable = GetComponent<Draggable>();
            }

            if (!_positionSaver)
            {
                _positionSaver = GetComponent<PositionSaver>();
            }

            if (!_linearMover)
            {
                _linearMover = GetComponent<LinearMover>();
            }

            if (!_matchHandler)
            {
                _matchHandler = GetComponent<ShapeMatchHandler>();
            }

            if (!_slotDetector)
            {
                _slotDetector = GetComponent<SlotDetector>();
            }
        }

        private void SubscribeToEvents()
        {
            if (!_draggable)
            {
                return;
            }

            _draggable.OnStartDrag.AddListener(HandleDragStart);
            _draggable.OnEndDrag.AddListener(HandleDragEnd);
        }

        private void UnsubscribeFromEvents()
        {
            if (!_draggable)
            {
                return;
            }

            _draggable.OnStartDrag.RemoveListener(HandleDragStart);
            _draggable.OnEndDrag.RemoveListener(HandleDragEnd);
        }

        private void HandleDragStart()
        {
            if (_positionSaver)
            {
                _positionSaver.SaveCurrentPosition();
            }

            if (_linearMover)
            {
                _linearMover.StopMovement();
            }
        }

        private void HandleDragEnd()
        {
            SortingSlot targetSlot = null;
            
            if (_slotDetector)
            {
                targetSlot = _slotDetector.GetSlotAtPosition(transform.position);
            }

            if (targetSlot)
            {
                ProcessShapeInSlot(targetSlot);
            }
            else
            {
                ReturnToOriginalPosition();
            }
        }

        private void ProcessShapeInSlot(SortingSlot slot)
        {
            if (_matchHandler && _shape)
            {
                _matchHandler.ProcessShapeInSlot(_shape, slot);
            }
        }

        private void ReturnToOriginalPosition()
        {
            if (_positionSaver && _positionSaver.HasPosition)
            {
                RestorePositionAnimated();
            }
            else
            {
                ResumeMovement();
            }
        }

        private void RestorePositionAnimated()
        {
            Vector3 targetPosition = _positionSaver.GetSavedPosition();
            
            transform.DOMove(targetPosition, _returnAnimationDuration)
                .SetEase(Ease.OutBack)
                .OnComplete(ResumeMovement);
        }

        private void ResumeMovement()
        {
            if (_linearMover)
            {
                _linearMover.StartMovement();
            }
        }

        public void SetReturnAnimationDuration(float duration)
        {
            _returnAnimationDuration = duration;
        }
    }
}