﻿using System;
using UnityEngine;

namespace Project.Оld.Game.Behaviours
{
    public sealed class LinearMover : MonoBehaviour
    {
        public event Action OnMovementStarted;
        public event Action OnMovementStopped;

        [Header("Movement Settings")]
        [SerializeField]
        private Vector3 _velocity = Vector3.right;
        
        [SerializeField]
        private bool _moveOnStart = true;
        
        [Header("Status")]
        [SerializeField]
        private bool _isMoving = false;

        public Vector3 Velocity => _velocity;
        
        public bool IsMoving => _isMoving;

        private void Start()
        {
            if (_moveOnStart)
            {
                StartMovement();
            }
        }

        private void Update()
        {
            if (_isMoving)
            {
                transform.position += _velocity * Time.deltaTime;
            }
        }

        public void StartMovement()
        {
            if (_isMoving)
            {
                return;
            }

            _isMoving = true;
            OnMovementStarted?.Invoke();
        }

        public void StopMovement()
        {
            if (!_isMoving)
            {
                return;
            }

            _isMoving = false;
            OnMovementStopped?.Invoke();
        }

        public void ToggleMovement()
        {
            if (_isMoving)
            {
                StopMovement();
            }
            else
            {
                StartMovement();
            }
        }

        public void SetVelocity(Vector3 newVelocity)
        {
            _velocity = newVelocity;
        }

        public void SetSpeed(float speed)
        {
            if (_velocity != Vector3.zero)
            {
                _velocity = _velocity.normalized * speed;
            }
        }

        public float GetSpeed()
        {
            return _velocity.magnitude;
        }
    }
}