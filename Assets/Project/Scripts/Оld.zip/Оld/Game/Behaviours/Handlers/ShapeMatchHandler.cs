﻿using Project.Оld.Game.Shape;
using UnityEngine;
using Zenject;

namespace Project.Оld.Game.Behaviours.Handlers
{
    public sealed class ShapeMatchHandler : MonoBehaviour
    {
        private SignalBus _signalBus;

        [Header("Components")]
        [SerializeField]
        private SlotComparison _slotComparison;

        [Inject]
        private void Init(SignalBus signalBus)
        {
            _signalBus = signalBus;
        }

        public bool ProcessShapeInSlot(DefaultShape shape, SortingSlot slot)
        {
            if (!shape || !slot)
            {
                return false;
            }

            if (_slotComparison.IsShapeMatchingSlot(shape.Data, slot))
            {
                HandleCorrectMatch(shape, slot);
                return true;
            }
            else
            {
                HandleIncorrectMatch(shape, slot);
                return false;
            }
        }

        private void HandleCorrectMatch(DefaultShape shape, SortingSlot slot)
        {
            var signal = new ShapeMatchedSignal
            {
                Shape = shape,
                ScoreValue = shape.Data.ScoreValue,
                Slot = slot,
                MatchPosition = slot.transform.position,
                MatchEffectId = shape.Data.MatchEffectId,
                MatchSoundId = shape.Data.MatchSoundId
            };

            _signalBus.Fire(signal);
        }

        private void HandleIncorrectMatch(DefaultShape shape, SortingSlot slot)
        {
            var signal = new ShapeExplodedSignal
            {
                Shape = shape,
                HealthPenalty = shape.Data.HealthPenalty,
                ExplosionPosition = shape.transform.position,
                ExplosionEffectId = shape.Data.ExplosionEffectId,
                ExplosionSoundId = shape.Data.ExplosionSoundId
            };

            _signalBus.Fire(signal);
        }
    }
}