﻿using Project.Оld.Common.Entities;
using UnityEngine;

namespace Project.Оld.Game.Behaviours.Handlers
{
    public sealed class SlotComparison : MonoBehaviour
    {
        public bool IsShapeMatchingSlot(EntityData data, SortingSlot slot)
        {
            if (!data ||
                !slot)
            {
                return false;
            }

            return data.Id == slot.Data.Id;
        }
    }
}