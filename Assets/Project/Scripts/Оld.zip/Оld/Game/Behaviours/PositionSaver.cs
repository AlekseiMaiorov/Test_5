﻿using System;
using DG.Tweening;
using UnityEngine;

namespace Project.Оld.Game.Behaviours
{
    public sealed class PositionSaver : MonoBehaviour
    {
        public Action<Vector3> OnPositionSaved;
        public Action<Vector3> OnPositionRestored;

        [Header("Position Settings")]
        [SerializeField]
        private bool _saveOnStart = false;
        [SerializeField]
        private float _restoreAnimationDuration;

        private Vector3 _savedPosition;
        private bool _hasPosition = false;

        public Vector3 SavedPosition => _savedPosition;
        public bool HasPosition => _hasPosition;

        private void Start()
        {
            if (!_saveOnStart)
            {
                return;
            }

            SaveCurrentPosition();
        }

        public void SaveCurrentPosition()
        {
            _savedPosition = transform.position;
            _hasPosition = true;
            OnPositionSaved?.Invoke(_savedPosition);
        }

        public void SavePosition(Vector3 position)
        {
            _savedPosition = position;
            _hasPosition = true;
            OnPositionSaved?.Invoke(_savedPosition);
        }

        public void RestorePosition()
        {
            if (!_hasPosition)
            {
                return;
            }

            transform.position = _savedPosition;
            OnPositionRestored?.Invoke(_savedPosition);
        }
        
        public void RestorePositionAnimated(Action onComplete = null)
        {
            if (!_hasPosition) return;

            transform.DOMove(_savedPosition, _restoreAnimationDuration)
                     .SetEase(Ease.OutBack)
                     .OnComplete(() =>
                                 {
                                     RestorePosition();
                                     onComplete?.Invoke();
                                 });
        }

        public Vector3 GetSavedPosition()
        {
            return _savedPosition;
        }

        public void ClearSavedPosition()
        {
            _hasPosition = false;
            _savedPosition = Vector3.zero;
        }
    }
}