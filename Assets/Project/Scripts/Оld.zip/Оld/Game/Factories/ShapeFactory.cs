﻿using Project.Оld.Game.Shape;
using UnityEngine;
using Zenject;

namespace Project.Оld.Game.Factories
{
    public interface IShapeFactory
    {
        DefaultShape CreateShape(ShapeData shapeData, Vector3 position);
    }

    public sealed class ShapeFactory : IShapeFactory
    {
        private readonly DiContainer _container;
        private readonly ShapePrefabLibrary _prefabLibrary;

        public ShapeFactory(DiContainer container, ShapePrefabLibrary prefabLibrary)
        {
            _container = container;
            _prefabLibrary = prefabLibrary;
        }

        public DefaultShape CreateShape(ShapeData shapeData, Vector3 position)
        {
            GameObject prefab = _prefabLibrary.GetShapePrefab(shapeData.ShapeType);
            if (!prefab)
            {
                Debug.LogError($"No prefab found for shape type: {shapeData.ShapeType}");
                return null;
            }

            GameObject instance = _container.InstantiatePrefab(prefab, position, Quaternion.identity, null);
            DefaultShape shape = instance.GetComponent<DefaultShape>();

            if (!shape)
            {
                Debug.LogError($"Prefab {prefab.name} does not contain DefaultShape component");
                Object.Destroy(instance);
                return null;
            }

            shape.Init(shapeData);

            return shape;
        }
    }
}