﻿using System.Collections.Generic;
using System.Linq;
using Project.Оld.Game.Behaviours;
using Project.Оld.Game.Shape;
using UnityEngine;

namespace Project.Оld.Game.Slots
{
    public interface ISortingSlotsProvider
    {
        List<ShapeData> GetAvailableShapeData();
    }

    public sealed class SortingSlotsProvider : MonoBehaviour, ISortingSlotsProvider
    {
        [Header("Sorting Slots")]
        [SerializeField]
        private List<SortingSlot> _sortingSlots = new List<SortingSlot>();
        
        public List<ShapeData> GetAvailableShapeData()
        {
            return _sortingSlots
                  .Where(slot => slot && slot.Data)
                  .Select(slot => slot.Data as ShapeData)
                  .Where(data => data)
                  .ToList();
        }
    }
}