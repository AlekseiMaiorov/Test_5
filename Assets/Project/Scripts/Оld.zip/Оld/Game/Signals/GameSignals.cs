﻿using Project.Оld.Game.Shape;
using UnityEngine;

namespace Project.Оld.Game.Signals
{

    public struct GameStartSignal
    {
        
    }

    public struct GameRestartSignal
    {
        
    }

    public struct ShapeProcessedSignal
    {
        public DefaultShape Shape;
        public ProcessType ProcessType;
        public int ScoreChange;
        public int HealthChange;
        public Vector3 Position;
    }

    public struct UIUpdateSignal
    {
        public int CurrentHealth;
        public int CurrentScore;
    }

    public struct GameEndSignal
    {
        public bool IsVictory;
        public int FinalScore;
        public string Reason;
    }

    public enum ProcessType
    {
        Matched,
        Exploded,
        ReachedEnd
    }
}