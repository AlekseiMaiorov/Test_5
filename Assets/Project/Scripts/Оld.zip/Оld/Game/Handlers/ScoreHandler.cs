﻿using Project.Оld.Game.Storage;
using Zenject;

namespace Project.Оld.Game.Handlers
{
    public sealed class ScoreHandler : IInitializable, System.IDisposable
    {
        private readonly SignalBus _signalBus;
        private readonly IPlayerStorage _playerStorage;

        public ScoreHandler(SignalBus signalBus, IPlayerStorage playerStorage)
        {
            _signalBus = signalBus;
            _playerStorage = playerStorage;
        }

        public void Initialize()
        {
            _signalBus.Subscribe<ShapeMatchedSignal>(OnShapeMatched);
        }

        public void Dispose()
        {
            _signalBus.TryUnsubscribe<ShapeMatchedSignal>(OnShapeMatched);
        }

        private void OnShapeMatched(ShapeMatchedSignal signal)
        {
            _playerStorage.AddScore(signal.ScoreValue);
        }
    }
}