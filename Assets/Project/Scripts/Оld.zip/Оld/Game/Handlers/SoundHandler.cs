﻿using Project.Оld.Game.Servicies;
using Zenject;

namespace Project.Оld.Game.Handlers
{
    public sealed class SoundHandler : IInitializable
    {
        private SignalBus _signalBus;
        private ISoundService _soundService;

        [Inject]
        private void Init(SignalBus signalBus, ISoundService soundService)
        {
            _signalBus = signalBus;
            _soundService = soundService;
        }

        public void Initialize()
        {
            SubscribeToSignals();
        }

        private void OnDestroy()
        {
            UnsubscribeFromSignals();
        }

        private void SubscribeToSignals()
        {
            _signalBus.Subscribe<ShapeMatchedSignal>(OnShapeMatched);
            _signalBus.Subscribe<ShapeExplodedSignal>(OnShapeExploded);
        }

        private void UnsubscribeFromSignals()
        {
            _signalBus.TryUnsubscribe<ShapeMatchedSignal>(OnShapeMatched);
            _signalBus.TryUnsubscribe<ShapeExplodedSignal>(OnShapeExploded);
        }

        private void OnShapeMatched(ShapeMatchedSignal signal)
        {
            if (!string.IsNullOrEmpty(signal.MatchSoundId))
            {
                _soundService.PlaySound(signal.MatchSoundId);
            }
        }

        private void OnShapeExploded(ShapeExplodedSignal signal)
        {
            if (!string.IsNullOrEmpty(signal.ExplosionSoundId))
            {
                _soundService.PlaySound(signal.ExplosionSoundId);
            }
        }
    }
}