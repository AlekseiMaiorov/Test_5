﻿using Project.Оld.Game.Pools;
using UnityEngine;
using Zenject;

namespace Project.Оld.Game.Handlers
{
    public sealed class ShapeLifecycleHandler : MonoBehaviour, IInitializable
    {
        private SignalBus _signalBus;
        private IShapePool _shapePool;

        [Inject]
        private void Init(SignalBus signalBus, IShapePool shapePool)
        {
            _signalBus = signalBus;
            _shapePool = shapePool;
        }

        public void Initialize()
        {
            SubscribeToSignals();
        }

        private void OnDestroy()
        {
            UnsubscribeFromSignals();
        }

        private void SubscribeToSignals()
        {
            _signalBus.Subscribe<ShapeMatchedSignal>(OnShapeMatched);
            _signalBus.Subscribe<ShapeExplodedSignal>(OnShapeExploded);
            _signalBus.Subscribe<ShapeReachedEndSignal>(OnShapeReachedEnd);
        }

        private void UnsubscribeFromSignals()
        {
            _signalBus.TryUnsubscribe<ShapeMatchedSignal>(OnShapeMatched);
            _signalBus.TryUnsubscribe<ShapeExplodedSignal>(OnShapeExploded);
            _signalBus.TryUnsubscribe<ShapeReachedEndSignal>(OnShapeReachedEnd);
        }

        private void OnShapeMatched(ShapeMatchedSignal signal)
        {
            if (signal.Shape)
            {
                _shapePool.ReturnShape(signal.Shape);
            }
        }

        private void OnShapeExploded(ShapeExplodedSignal signal)
        {
            if (signal.Shape)
            {
                _shapePool.ReturnShape(signal.Shape);
            }
        }

        private void OnShapeReachedEnd(ShapeReachedEndSignal signal)
        {
            if (signal.Shape)
            {
                _shapePool.ReturnShape(signal.Shape);
            }
        }
    }
}