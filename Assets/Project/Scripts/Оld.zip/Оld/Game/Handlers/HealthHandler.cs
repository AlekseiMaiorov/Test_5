﻿using Project.Оld.Game.Storage;
using Zenject;

namespace Project.Оld.Game.Handlers
{
    public sealed class HealthHandler : IInitializable, System.IDisposable
    {
        private readonly SignalBus _signalBus;
        private readonly IPlayerStorage _playerStorage;

        public HealthHandler(SignalBus signalBus, IPlayerStorage playerStorage)
        {
            _signalBus = signalBus;
            _playerStorage = playerStorage;
        }

        public void Initialize()
        {
            _signalBus.Subscribe<ShapeExplodedSignal>(OnShapeExploded);
            _signalBus.Subscribe<ShapeReachedEndSignal>(OnShapeReachedEnd);
            _signalBus.Subscribe<PlayerHealthChangedSignal>(OnHealthChanged);
        }

        public void Dispose()
        {
            _signalBus.TryUnsubscribe<ShapeExplodedSignal>(OnShapeExploded);
            _signalBus.TryUnsubscribe<ShapeReachedEndSignal>(OnShapeReachedEnd);
            _signalBus.TryUnsubscribe<PlayerHealthChangedSignal>(OnHealthChanged);
        }

        private void OnShapeExploded(ShapeExplodedSignal signal)
        {
            _playerStorage.TakeDamage(signal.HealthPenalty);
        }

        private void OnShapeReachedEnd(ShapeReachedEndSignal signal)
        {
            _playerStorage.TakeDamage(signal.HealthPenalty);
        }

        private void OnHealthChanged(PlayerHealthChangedSignal signal)
        {
            if (signal.CurrentHealth <= 0)
            {
                TriggerGameOver();
            }
        }

        private void TriggerGameOver()
        {
            var gameOverSignal = new GameOverSignal
            {
                FinalScore = _playerStorage.CurrentScore,
                Reason = "No health left"
            };
            
            _signalBus.Fire(gameOverSignal);
        }
    }
}