﻿using Project.Оld.Game.Servicies;
using Zenject;

namespace Project.Оld.Game.Handlers
{
    public sealed class ParticleHandler : IInitializable
    {
        private SignalBus _signalBus;
        private IParticleService _particleService;

        [Inject]
        private void Init(SignalBus signalBus, IParticleService particleService)
        {
            _signalBus = signalBus;
            _particleService = particleService;
        }

        public void Initialize()
        {
            SubscribeToSignals();
        }

        private void OnDestroy()
        {
            UnsubscribeFromSignals();
        }

        private void SubscribeToSignals()
        {
            _signalBus.Subscribe<ShapeMatchedSignal>(OnShapeMatched);
            _signalBus.Subscribe<ShapeExplodedSignal>(OnShapeExploded);
        }

        private void UnsubscribeFromSignals()
        {
            _signalBus.TryUnsubscribe<ShapeMatchedSignal>(OnShapeMatched);
            _signalBus.TryUnsubscribe<ShapeExplodedSignal>(OnShapeExploded);
        }

        private void OnShapeMatched(ShapeMatchedSignal signal)
        {
            if (!string.IsNullOrEmpty(signal.MatchEffectId))
            {
                _particleService.PlayEffect(signal.MatchEffectId, signal.MatchPosition);
            }
        }

        private void OnShapeExploded(ShapeExplodedSignal signal)
        {
            if (!string.IsNullOrEmpty(signal.ExplosionEffectId))
            {
                _particleService.PlayEffect(signal.ExplosionEffectId, signal.ExplosionPosition);
            }
        }
    }
}