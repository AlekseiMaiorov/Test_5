﻿using Project.Оld.Game.Storage;
using Zenject;

namespace Project.Оld.Game.Handlers
{
    public sealed class RestartHandler : IInitializable, System.IDisposable
    {
        private readonly SignalBus _signalBus;
        private readonly IPlayerStorage _playerStorage;
        private readonly GameStateMachine _gameStateMachine;

        public RestartHandler(SignalBus signalBus, IPlayerStorage playerStorage, GameStateMachine gameStateMachine)
        {
            _gameStateMachine = gameStateMachine;
            _signalBus = signalBus;
            _playerStorage = playerStorage;
        }

        public void Initialize()
        {
            _signalBus.Subscribe<RestartGameSignal>(OnRestartGame);
        }

        public void Dispose()
        {
            _signalBus.TryUnsubscribe<RestartGameSignal>(OnRestartGame);
        }

        private void OnRestartGame()
        {
            _playerStorage.ResetStats();
            _gameStateMachine.ChangeState<LoadGameState>();
        }
    }
}