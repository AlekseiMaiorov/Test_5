﻿using Project.Оld.Game.Behaviours;
using Project.Оld.Game.Settings;
using Project.Оld.Game.Shape;
using UnityEngine;
using Zenject;

namespace Project.Оld.Game.Handlers
{
    public sealed class ShapeInitializer : IInitializable
    {
        private SignalBus _signalBus;
        private GameSettings _gameSettings;

        [Inject]
        private void Init(SignalBus signalBus, GameSettings gameSettings)
        {
            _signalBus = signalBus;
            _gameSettings = gameSettings;
        }

        public void Initialize()
        {
            SubscribeToSignals();
        }

        private void OnDestroy()
        {
            UnsubscribeFromSignals();
        }

        private void SubscribeToSignals()
        {
            _signalBus.Subscribe<ShapeSpawnedSignal>(OnShapeSpawned);
        }

        private void UnsubscribeFromSignals()
        {
            _signalBus.TryUnsubscribe<ShapeSpawnedSignal>(OnShapeSpawned);
        }

        private void OnShapeSpawned(ShapeSpawnedSignal signal)
        {
            if (!signal.Shape)
            {
                return;
            }

            SetupShapeMovement(signal.Shape);
        }

        private void SetupShapeMovement(DefaultShape shape)
        {
            var linearMover = shape.GetComponent<LinearMover>();
            if (!linearMover)
            {
                return;
            }

            float randomSpeed = Random.Range(_gameSettings.ShapeSpeedRange.x, _gameSettings.ShapeSpeedRange.y);
            Vector3 rightDirection = Vector3.right * randomSpeed;
            
            linearMover.SetVelocity(rightDirection);
            linearMover.StartMovement();
        }
    }
}