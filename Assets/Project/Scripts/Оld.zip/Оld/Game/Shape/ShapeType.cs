﻿namespace Project.Оld.Game.Shape
{
    public enum ShapeType
    {
        Default
        //Bonus,
        //Bomb
    }
}