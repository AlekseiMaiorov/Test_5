﻿using Project.Оld.Common.Entities;

namespace Project.Оld.Game.Shape
{
    public class DefaultShape : Entity<ShapeData>
    {
        
    }
}