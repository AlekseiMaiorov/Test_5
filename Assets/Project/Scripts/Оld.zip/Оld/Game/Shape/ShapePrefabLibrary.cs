﻿using System.Collections.Generic;
using AYellowpaper.SerializedCollections;
using UnityEngine;

namespace Project.Оld.Game.Shape
{
    [CreateAssetMenu(fileName = "ShapePrefabLibrary", menuName = "Game/Shape Prefab Library")]
    public class ShapePrefabLibrary : ScriptableObject
    {
        [Header("Shape Prefabs")]
        [SerializedDictionary]
        private SerializedDictionary<ShapeType, GameObject> _library = new SerializedDictionary<ShapeType, GameObject>();
    
        public GameObject GetShapePrefab(ShapeType shapeType)
        {
            return _library.GetValueOrDefault(shapeType);
        }
    }
}