﻿using System.Collections.Generic;
using AYellowpaper.SerializedCollections;
using Project.Оld.Game.Pools;
using UnityEngine;
using Zenject;

namespace Project.Оld.Game.Servicies
{
    public interface IParticleService
    {
        void PlayEffect(string effectId, Vector3 position);
    }

    public sealed class ParticleService : IParticleService
    {
        [Header("Particle Library")]
        [SerializedDictionary]
        [SerializeField]
        private SerializedDictionary<string, ParticleSystem> _particleLibrary =
            new SerializedDictionary<string, ParticleSystem>();

        private ParticlePool.Pool _particlePool;

        [Inject]
        private void Init(ParticlePool.Pool particlePool)
        {
            _particlePool = particlePool;
        }

        public void PlayEffect(string effectId, Vector3 position)
        {
            ParticleSystem prefab = GetParticlePrefab(effectId);
            if (!prefab)
            {
                return;
            }

            ParticlePool pooledParticle = _particlePool.Spawn(prefab, position);
            if (pooledParticle)
            {
                pooledParticle.PlayEffect();
            }
        }

        private ParticleSystem GetParticlePrefab(string effectId)
        {
            if (string.IsNullOrEmpty(effectId))
            {
                return null;
            }

            return _particleLibrary.GetValueOrDefault(effectId);
        }
    }
}