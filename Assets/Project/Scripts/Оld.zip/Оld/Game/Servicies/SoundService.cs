﻿using System.Collections.Generic;
using AYellowpaper.SerializedCollections;
using UnityEngine;

namespace Project.Оld.Game.Servicies
{
    public interface ISoundService
    {
        void PlaySound(string soundId);
        void SetMasterVolume(float volume);
    }

    public sealed class SoundService : MonoBehaviour, ISoundService
    {
        [Header("Sound Library")]
        [SerializedDictionary]
        [SerializeField]
        private SerializedDictionary<string, AudioClip> _soundLibrary = new SerializedDictionary<string, AudioClip>();

        [Header("Audio Source")]
        [SerializeField]
        private AudioSource _audioSource;

        private void Start()
        {
            if (!_audioSource)
            {
                _audioSource = GetComponent<AudioSource>();
                if (!_audioSource)
                {
                    _audioSource = gameObject.AddComponent<AudioSource>();
                }
            }
        }

        public void PlaySound(string soundId)
        {
            AudioClip clip = GetSoundClip(soundId);
            if (clip)
            {
                _audioSource.PlayOneShot(clip);
            }
        }

        public void SetMasterVolume(float volume)
        {
            _audioSource.volume = Mathf.Clamp01(volume);
        }

        private AudioClip GetSoundClip(string soundId)
        {
            if (string.IsNullOrEmpty(soundId))
            {
                return null;
            }

            return _soundLibrary.GetValueOrDefault(soundId);
        }
    }
}