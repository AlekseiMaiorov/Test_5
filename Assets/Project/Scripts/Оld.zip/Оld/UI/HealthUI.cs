﻿using TMPro;
using UnityEngine;
using Zenject;

namespace Project.Оld.UI
{
    public sealed class HealthUI : MonoBehaviour, IInitializable
    {
        private SignalBus _signalBus;

        [Header("UI Components")]
        [SerializeField]
        private TextMeshProUGUI _healthText;

        [Header("Settings")]
        [SerializeField]
        private string _healthFormat = "Health: {0}";

        [Inject]
        private void Init(SignalBus signalBus)
        {
            _signalBus = signalBus;
        }

        public void Initialize()
        {
            _signalBus.Subscribe<PlayerHealthChangedSignal>(OnHealthChanged);
        }

        private void OnDestroy()
        {
            _signalBus.TryUnsubscribe<PlayerHealthChangedSignal>(OnHealthChanged);
        }

        private void OnHealthChanged(PlayerHealthChangedSignal signal)
        {
            UpdateDisplay(signal.CurrentHealth);
        }

        private void UpdateDisplay(int health)
        {
            if (_healthText)
            {
                _healthText.text = string.Format(_healthFormat, health);
            }
        }
    }
}