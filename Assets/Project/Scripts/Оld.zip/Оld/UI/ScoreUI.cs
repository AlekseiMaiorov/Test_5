﻿using TMPro;
using UnityEngine;
using Zenject;

namespace Project.Оld.UI
{
    public sealed class ScoreUI : MonoBehaviour, IInitializable
    {
        private SignalBus _signalBus;

        [Header("UI Components")]
        [SerializeField]
        private TextMeshProUGUI _scoreText;

        [Header("Settings")]
        [SerializeField]
        private string _scoreFormat = "Score: {0}";

        [Inject]
        private void Init(SignalBus signalBus)
        {
            _signalBus = signalBus;
        }

        public void Initialize()
        {
            _signalBus.Subscribe<ScoreChangedSignal>(OnScoreChanged);
        }

        private void OnDestroy()
        {
            _signalBus.TryUnsubscribe<ScoreChangedSignal>(OnScoreChanged);
        }

        private void OnScoreChanged(ScoreChangedSignal signal)
        {
            UpdateDisplay(signal.CurrentScore);
        }

        private void UpdateDisplay(int score)
        {
            if (_scoreText)
            {
                _scoreText.text = string.Format(_scoreFormat, score);
            }
        }
    }
}