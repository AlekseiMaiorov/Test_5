﻿using UnityEngine;
using UnityEngine.UI;
using Zenject;

namespace Project.Оld.UI
{
    public sealed class GameOverPopup : MonoBehaviour, IInitializable
    {
        private SignalBus _signalBus;

        [Header("UI Components")]
        [SerializeField]
        private GameObject _popupPanel;

        [SerializeField]
        private Button _restartButton;

        [Inject]
        private void Init(SignalBus signalBus)
        {
            _signalBus = signalBus;
        }

        public void Initialize()
        {
            _signalBus.Subscribe<GameOverSignal>(OnGameOver);
            SetupButtons();
            Hide();
        }

        private void OnDestroy()
        {
            _signalBus.TryUnsubscribe<GameOverSignal>(OnGameOver);
        }

        private void SetupButtons()
        {
            if (_restartButton)
            {
                _restartButton.onClick.AddListener(OnRestartClicked);
            }
        }

        private void OnGameOver(GameOverSignal signal)
        {
            Show();
        }

        private void OnRestartClicked()
        {
            Hide();
            _signalBus.Fire<RestartGameSignal>();
        }

        private void Show()
        {
            if (_popupPanel)
            {
                _popupPanel.SetActive(true);
            }
        }

        private void Hide()
        {
            if (_popupPanel)
            {
                _popupPanel.SetActive(false);
            }
        }
    }
}