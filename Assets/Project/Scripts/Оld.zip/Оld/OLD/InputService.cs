using UnityEngine;
using Zenject;
using ClickSignal = Project.Оld.Inputs.OLD.InputSignal<Project.Оld.Inputs.OLD.InputEventData.ClickEventData>;
using DragSignal = Project.Оld.Inputs.OLD.InputSignal<Project.Оld.Inputs.OLD.InputEventData.DragEventData>;
using ReleaseSignal = Project.Оld.Inputs.OLD.InputSignal<Project.Оld.Inputs.OLD.InputEventData.ReleaseEventData>;

namespace Project.Оld.Inputs.OLD
{
    public sealed class InputService : ITickable
    {
        private readonly SignalBus _signalBus;
        private readonly Camera _mainCamera;

        private RaycastHit2D  _currentHit;
        private bool _hasValidHit = false;
        private bool _isDragging = false;
        private Vector2 _lastMousePosition;
        private float _dragStartTime;

        public InputService(SignalBus signalBus, Camera mainCamera)
        {
            _signalBus = signalBus;
            _mainCamera = mainCamera;
        }

        public void Tick()
        {
            HandleInput();
        }

        private void HandleInput()
        {
            HandleClick();
            HandleDrag();
            HandleRelease();
        }

        private void HandleClick()
        {
            if (!Input.GetMouseButtonDown(0))
            {
                return;
            }

            Vector2 worldPos = _mainCamera.ScreenToWorldPoint(Input.mousePosition);
            _currentHit = Physics2D.Raycast(worldPos, Vector2.zero);
            _hasValidHit = _currentHit.collider;

            if (!_hasValidHit)
            {
                return;
            }

            var clickData = new InputEventData.ClickEventData
            {
                WorldClickPosition = worldPos,
                Button = 0
            };

            _signalBus.Fire(new ClickSignal(_currentHit, clickData));

            _isDragging = true;
            _lastMousePosition = worldPos;
            _dragStartTime = Time.time;
        }

        private void HandleDrag()
        {
            if (!_isDragging ||
                !_hasValidHit ||
                !Input.GetMouseButton(0))
            {
                return;
            }

            Vector2 currentMousePos = _mainCamera.ScreenToWorldPoint(Input.mousePosition);
            Vector2 delta = currentMousePos - (Vector2)_lastMousePosition;

            var dragData = new InputEventData.DragEventData
            {
                CurrentWorldPosition = currentMousePos,
                WorldDeltaPosition = delta,
                DragDuration = Time.time - _dragStartTime
            };

            _signalBus.Fire(new DragSignal(_currentHit, dragData));
            _lastMousePosition = currentMousePos;
        }

        private void HandleRelease()
        {
            if (!Input.GetMouseButtonUp(0))
            {
                return;
            }
            
            Vector2 releaseWorldPos = _mainCamera.ScreenToWorldPoint(Input.mousePosition);

            var releaseData = new InputEventData.ReleaseEventData
            {
                WorldReleasePosition = releaseWorldPos,
                TotalDragTime = _isDragging ? Time.time - _dragStartTime : 0f,
                WasDragging = _isDragging
            };

            if (_hasValidHit)
            {
                _signalBus.Fire(new ReleaseSignal(_currentHit, releaseData));
            }

            _isDragging = false;
            _hasValidHit = false;
        }
    }
}