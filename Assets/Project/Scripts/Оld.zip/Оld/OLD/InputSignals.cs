﻿using UnityEngine;

namespace Project.Оld.Inputs.OLD
{
    public interface IInputEventData { }

    public struct InputSignal<T> where T : struct, IInputEventData
    {
        public RaycastHit2D Hit { get; }
        public T Data { get; }
        public float Timestamp { get; }
    
        public InputSignal(in RaycastHit2D hit, in T data)
        {
            Hit = hit;
            Data = data;
            Timestamp = Time.time;
        }
    }
}