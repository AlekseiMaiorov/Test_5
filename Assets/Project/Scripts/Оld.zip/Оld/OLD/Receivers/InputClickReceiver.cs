﻿// using UnityEngine;
// using Zenject;
//
// namespace Project.Inputs.Receivers
// {
//     namespace Project.Inputs
//     {
//         public abstract class InputClickReceiver<T> : MonoBehaviour where T : struct, IInputEventData
//         {
//             [Inject]
//             protected SignalBus _signalBus;
//             
//             [SerializeField]
//             private BaseSignal[] _baseSignal;
//
//             private void Start()
//             {
//                 SubscribeToInputSignals();
//             }
//
//             private void SubscribeToInputSignals()
//             {
//                 _signalBus.Subscribe<InputSignal<T>>(OnInputReceived);
//             }
//
//             protected virtual void OnInputReceived(InputSignal<T> inputSignal)
//             {
//                 
//                 if (inputSignal.Hit.collider && inputSignal.Hit.collider.gameObject == gameObject)
//                 {
//                     ProcessInput(inputSignal);
//                 }
//             }
//
//             protected abstract void ProcessInput(InputSignal<T> inputSignal);
//
//             public virtual void SendSignal()
//             {
//                 foreach (var baseSignal in _baseSignal)
//                 {
//                     _signalBus.Fire(baseSignal);
//                 }
//             }
//
//             private void OnDestroy()
//             {
//                 _signalBus?.TryUnsubscribe<InputSignal<T>>(OnInputReceived);
//             }
//         }
//     }
// }
//
// namespace Project.Inputs.Receivers.Project.Inputs
// {
//     public class BaseSignal<T> where T : struct, IInputEventData
//     {
//         
//     }
//
//     public class MovementBehaviourSignal<T> : BaseSignal<T> where T : struct, IInputEventData
//     {
//         public T Data;
//         public bool IsStop;
//     }
// }