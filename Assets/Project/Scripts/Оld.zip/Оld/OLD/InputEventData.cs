﻿

using UnityEngine;

namespace Project.Оld.Inputs.OLD
{
    public class InputEventData
    {
        public struct ClickEventData : IInputEventData
        {
            public Vector2 WorldClickPosition;
            public int Button; // 0 - левый, 1 - правый, 2 - средний
        }

        public struct DragEventData : IInputEventData
        {
            public Vector2 CurrentWorldPosition;
            public Vector2 WorldDeltaPosition;
            public float DragDuration;
        }

        public struct ReleaseEventData : IInputEventData
        {
            public Vector2 WorldReleasePosition;
            public float TotalDragTime;
            public bool WasDragging;
        }
    }
}